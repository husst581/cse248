package net.androidbootcamp.parkassist;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class renewMember extends AppCompatActivity {
    private Spinner vehicleSpinner;
    databaseClass db;
    EditText driverID;
    EditText stateOfId;
    EditText Drivername;
    EditText RegistrationNo;
    EditText attandee;
    EditText pass;
    String idDriver;
    String idState;
    String DriverName;
    String registration;
    String Attendee;
    String PassPkg;
    String LookUp;
    String dateExpire;
    String DateTime;
    Button generate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_renew_member);
        db = new databaseClass(this);
        // sending edit text fields to another activity
        driverID = (EditText) (findViewById(R.id.driverId));
        stateOfId = (EditText) (findViewById(R.id.state));
        Drivername = (EditText) (findViewById(R.id.fullName));
        RegistrationNo = (EditText) (findViewById(R.id.registration));
        attandee = (EditText) (findViewById(R.id.attendee));
        pass = (EditText) (findViewById(R.id.pass));
        LookUp = RegistrationNo.getText().toString();
        generate=(Button)(findViewById(R.id.updateMember));
        getTime();
        setupSpinner();
        generate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DriverName=Drivername.getText().toString();
                idState=stateOfId.getText().toString();;
                idDriver=driverID.getText().toString();
                registration=RegistrationNo.getText().toString();
                PassPkg=pass.getText().toString();
                Attendee=attandee.getText().toString();
                RenewMember(DriverName, idDriver, idState, registration, DateTime, Attendee, PassPkg,dateExpire);
            }
        });

    }

    public void LookUpRecord(View view) {
        Cursor cursor = db.lookup(LookUp);
        ;
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    DriverName = cursor.getString(cursor.getColumnIndex("Name"));
                    registration = cursor.getString(cursor.getColumnIndex("Registration"));
                    idDriver = cursor.getString(cursor.getColumnIndex("DriversID"));
                    idState = cursor.getString(cursor.getColumnIndex("StateOfID"));
                    PassPkg = cursor.getString(cursor.getColumnIndex("PackageType"));
                }
            } finally {
                cursor.close();
            }
        }
        Attendee = attandee.getText().toString();


    }

    public void RenewMember(String driver, String id, String state, String registration, String date, String Attendee, String pkg,String exp) {
        if (driver.equals("") || id.equals("") || date.equals("") ||
                state.equals("") || registration.equals("") ||
                pkg.equals("") || Attendee.equals("")) {
            Toast.makeText(getApplicationContext(), "fields are empty", Toast.LENGTH_SHORT).show();
        } else {
            Boolean ins = db.insertMember(driver, id, state, registration, date, Attendee, pkg, exp);
            if (ins == true) {
                Toast.makeText(getApplicationContext(), "data inserted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(), "no data stored", Toast.LENGTH_SHORT).show();
            }

        }
    }


    public void setupSpinner() {
        // Create adapter for spinner. The list options are from the String array it will use
        // the spinner will use the default layout
        ArrayAdapter genderSpinnerAdapter = ArrayAdapter.createFromResource(this,
                R.array.ArrayVhehicleOption, android.R.layout.simple_spinner_item);

        // Specify dropdown layout style - simple list view with 1 item per line
        genderSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        // Apply the adapter to the spinner
        vehicleSpinner.setAdapter(genderSpinnerAdapter);

        // Set the integer mSelected to the constant values
        vehicleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selection = (String) parent.getItemAtPosition(position);
                if (!TextUtils.isEmpty(selection)) {
                    if (selection.equals(getString(R.string.truckDay))) {
                        PassPkg = "Truck- Daily";
                        dateExpire=DateTime;
                    } else if (selection.equals(getString(R.string.truckW))) {
                        PassPkg = "Truck- Weekly";
                        getWeek();
                    } else if (selection.equals(getString(R.string.truckM))) {
                        PassPkg = "Truck- Monthly";
                        getMonth();
                    } else if (selection.equals(getString(R.string.doorDay))) {
                        PassPkg = "2D or 4D Sedan/CrossOver- Daily";
                        dateExpire=DateTime;

                    } else if (selection.equals(getString(R.string.doorW))) {
                        PassPkg = "2D or 4D Sedan/CrossOver- Weekly";
                        getWeek();
                        }
                    else if (selection.equals(getString(R.string.doorM))) {
                        PassPkg = "2D or 4D Sedan/CrossOver- Monthly";
                        getMonth();
                    }
                    else if (selection.equals(getString(R.string.SuvDay))) {
                        PassPkg = "SUV'S/PickUp Truck- Daily ";
                        dateExpire=DateTime;
                    }
                    else if (selection.equals(getString(R.string.SuvW))) {
                        PassPkg = "SUV'S/PickUp Truck- Weekly";
                        getWeek();
                    }else if (selection.equals(getString(R.string.SuvM))) {
                        PassPkg = "SUV'S/PickUp Truck- Monthly";
                        getMonth();
                    }
                }
            }

            public void onNothingSelected(AdapterView<?> parent) {
                PassPkg = "Unknown";
            }
        });
    }


    public void getTime() {
        DateTimeFormatter df = DateTimeFormatter.ofPattern("MM/dd/yy");
        LocalDateTime now = LocalDateTime.now();
        DateTime = df.format(now).toString();

    }

    public void getMonth() {
        String month = DateTime.substring(0, 1);//new
        String year = DateTime.substring(7);
        ;//new
        char[] monthEx = month.toCharArray();//old
        char[] yearEx = year.toCharArray();//new
        int checkMonth = ((monthEx[0] - '0') * 10) + (monthEx[1] - '0');
        if (checkMonth < 12) {
            checkMonth = checkMonth + 1;
            dateExpire = Integer.toString(checkMonth) + DateTime.substring(2);

        } else {
           String firstM="01";
            int exYear = ((yearEx[0] - '0') * 10) + (yearEx[1] - '0');
            exYear = exYear + 1;
            dateExpire = firstM + DateTime.substring(2, 5) + Integer.toString(exYear);
        }
    }

    public void getWeek() {
        String Days = DateTime.substring(3, 4);//new
        String month = DateTime.substring(0, 1);
        String year = DateTime.substring(7);
        ;//new
        char[] DayEx = Days.toCharArray();//old
        char[] monthEx = month.toCharArray();//new
        char[] yearEx = year.toCharArray();//new

        int checkDay = ((DayEx[0] - '0') * 10) + (DayEx[1] - '0');
        if (checkDay <= 15) {
            checkDay = checkDay + 15;
            dateExpire = DateTime.substring(0, 2) + Integer.toString(checkDay) + DateTime.substring(5);}
            else {
            checkDay=checkDay+15;
            checkDay=checkDay-30;
            if(checkDay==1) {  String first="01";
            dateExpire=DateTime.substring(0, 2)+ first+ DateTime.substring(5);}
            else{
                int checkMonth = ((monthEx[0] - '0') * 10) + (monthEx[1] - '0');
                if (checkMonth < 12) {
                    checkMonth = checkMonth + 1;
                    dateExpire = Integer.toString(checkMonth) + Integer.toString(checkDay)+ DateTime.substring(5);

                } else {
                    String firstM = "01";
                    int exYear = ((yearEx[0] - '0') * 10) + (yearEx[1] - '0');
                    exYear = exYear + 1;
                    dateExpire = firstM + DateTime.substring(2, 5) + Integer.toString(exYear);
                }


            }

        }
    }
    public void UpdateMember(View view){
        DriverName=Drivername.getText().toString();
        idState=stateOfId.getText().toString();;
        idDriver=driverID.getText().toString();
        registration=RegistrationNo.getText().toString();
        PassPkg=pass.getText().toString();
        Attendee=attandee.getText().toString();
        RenewMember(DriverName, idDriver, idState, registration, DateTime, Attendee, PassPkg,dateExpire);


    }


}