package net.androidbootcamp.parkassist;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class unparkTicket extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unpark_ticket);
        FloatingActionButton fabHome = (FloatingActionButton) findViewById(R.id.float_home);
        fabHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchLayout();}});

        TextView driverName = (TextView) findViewById(R.id.driverUnpark);
        TextView registrationNo = (TextView) findViewById(R.id.registrationUnpark);
        TextView timeIn = (TextView) findViewById(R.id.timeInUnpark);
        TextView timeOut = (TextView) findViewById(R.id.timeOutUnpark);
        TextView TotalPay = (TextView) findViewById(R.id.totalUnpark);
        //assinging values  to strings which are coming from driverInformation to textboxes in ticket print layout
        Intent intent = getIntent();
        String drivername = intent.getStringExtra("driverName");
        String registration = intent.getStringExtra("registration");
        String timein = intent.getStringExtra("timeIn");
        String Timeout = intent.getStringExtra("timeOut");
        String total = intent.getStringExtra("total");
        // textviews are equal to string
        driverName.setText(drivername);
        registrationNo.setText(registration);
        timeIn.setText(timein);
        timeOut.setText(Timeout);
        TotalPay.setText(total);
    }

    public void paid(View v){

        Toast.makeText(getApplicationContext(),"Paid, Thanks have a nice day!",Toast.LENGTH_SHORT).show();
    }
    public void switchLayout() {
        Intent searchIntent = new Intent(unparkTicket.this, MainActivity.class);
        startActivity(searchIntent);
    }
}
