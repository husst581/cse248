package net.androidbootcamp.parkassist;

import android.content.Intent;
import android.database.Cursor;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class unPark extends AppCompatActivity {
    databaseClass db;
    EditText findRecord;
    String registrationNo;
    String nameFound;
    String regFound;
    String timeIn, timeOut,dateIn;
    String totalPay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_un_park);
        FloatingActionButton fabHome = (FloatingActionButton) findViewById(R.id.float_home);
        fabHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchLayout();}});


        findRecord = (EditText) findViewById(R.id.searchByReg);
        registrationNo = findRecord.getText().toString();
        db = new databaseClass(this);


    }
        public void FindRecord(){
        Cursor cursor=db.findCar(registrationNo);;
        if(cursor!=null){
            try{
                if(cursor.moveToFirst()){
                    nameFound=cursor.getString(cursor.getColumnIndex("name"));
                    regFound=cursor.getString(cursor.getColumnIndex("Registration"));
                    timeIn=cursor.getString(cursor.getColumnIndex("Time"));
                    dateIn=cursor.getString(cursor.getColumnIndex("Date"));

                }
            }finally {
                cursor.close();
            }
        }

    }


    public void generateCheckOut(View view){
        FindRecord();
        getTotalPay(timeIn,dateIn);

        Intent intent = new Intent(unPark.this, unparkTicket.class);
        intent.putExtra( "driverName", nameFound);
        intent.putExtra( "total", totalPay);
        intent.putExtra( "registration", regFound);
        intent.putExtra( "timeIn", timeIn);
        intent.putExtra( "timeOut",timeOut);

    }
    public void getTotalPay(String time,String date) {
        DateTimeFormatter df = DateTimeFormatter.ofPattern("MM/dd/yy HH:mm");
        LocalDateTime now = LocalDateTime.now();
        String DateTime = df.format(now).toString();
        String dateA = date;//arrival
        String timeA = time;//arrival
        String nowDate = DateTime.substring(0, 8);//new
        String NowTime = DateTime.substring(9);;//new
        char[] timeArr = timeA.toCharArray();//old
        char[] nowTime = NowTime.toCharArray();//new
        char[] dateArr = dateA.toCharArray();//old
        char[] NowDate = nowDate.toCharArray();//new
        double dateDiff = ((NowDate[3] - '0') * 10 + (NowDate[4] - '0')) - ((dateArr[3] - '0') * 10 + (dateArr[4] - '0'));
        double hour = (timeArr[0] - '0') * 10 + (timeArr[1] - '0');
        double min = ((timeArr[3] - '0') * 10 + (timeArr[4] - '0')) / 100.0;
        double hourtot = ((nowTime[0] - '0') * 10 )+ ((nowTime[1] - '0'));
        double mintot = ((nowTime[3] - '0') * 10 + (nowTime[4] - '0')) / 100.0;
        double TotalHours = dateDiff * 24;
        double totalTime = (hourtot + mintot) + TotalHours - (hour + min);
        double TotalHourtime=30;
       totalTime=  totalTime-1;
       int hours= (int)(totalTime/1); //has the hours
       double remain=totalTime%1;
       if(remain>=21 ||remain<=30) TotalHourtime=TotalHourtime+15;
           else if(remain>=11 ||remain<=20)  TotalHourtime=TotalHourtime+10;
           else if(remain>=11 ||remain<=20)  TotalHourtime=TotalHourtime+5;
          else if(remain>=31) TotalHourtime=TotalHourtime+20;
          TotalHourtime=TotalHourtime+(hours*20);
          totalPay=String.valueOf(TotalHourtime);
       }
    public void switchLayout() {
        Intent searchIntent = new Intent(unPark.this, MainActivity.class);
        startActivity(searchIntent);
    }



    }
