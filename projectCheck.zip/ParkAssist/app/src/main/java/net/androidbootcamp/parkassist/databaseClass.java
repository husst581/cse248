package net.androidbootcamp.parkassist;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class databaseClass  extends SQLiteOpenHelper {
   public static final String tableName="DriverInformation";
    public static final String tableName2="Package";
    public static final  String nameColumn="Name";
    public static final  String idColumn="DriversID";
    public static final  String registrationColumn="Registration";
    public static final  String stateColumn="StateofID";
    public static final  String dateColumn="Date";
    public static final  String timeColumn="Time";
    public static final  String attendentColumn="Attendee";
    public databaseClass(Context context) {
        super(context, "driver2.db" , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + tableName +
                  "(ID integer primary key autoincrement,"
                + nameColumn +" text,"
                + idColumn + " text,"
                + stateColumn+" text,"
                + registrationColumn+ " text,"
                +dateColumn+" text,"
                +timeColumn+" text,"
                +attendentColumn+ " text, SpotNo text)");




        db.execSQL("create table " + tableName2 +
                "(ID integer primary key autoincrement,"
                + nameColumn +" text,"
                + idColumn + " text,"
                + stateColumn+" text,"
                + registrationColumn+ " text,"
                +attendentColumn+ " text, PackageType text, PackageExpire Text)" );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + tableName );
        db.execSQL("drop table if exists "+tableName2);
    }


    public boolean insert(String name, String id, String state, String registration,
    String date, String time, String Attendee, String spotNo)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(nameColumn, name);
        contentValues.put(idColumn, id);
        contentValues.put(stateColumn, state);
        contentValues.put(registrationColumn, registration);
        contentValues.put(dateColumn, date);
        contentValues.put(timeColumn, time);
        contentValues.put(attendentColumn, Attendee);
        contentValues.put("SpotNo", spotNo);
        long ins=db.insert(tableName,null,contentValues);
        if(ins==-1) return false;
        else return true;

    }
    public Cursor findCar(String Registration){
      SQLiteDatabase db=this.getReadableDatabase();
      String where="Registration =?";
      String[] whereArgs={Registration};

      return db.query(tableName,null,where,whereArgs,null,null,null);

    }
  public boolean UpdateParking(String name, String id, String state, String registration,
                               String date, String time, String Attendee, String spotNo)
  {
      SQLiteDatabase db=this.getWritableDatabase();
      ContentValues contentValues=new ContentValues();
      contentValues.put(nameColumn, name);
      contentValues.put(idColumn, id);
      contentValues.put(stateColumn, state);
      contentValues.put(registrationColumn, registration);
      contentValues.put(dateColumn, date);
      contentValues.put(timeColumn, time);
      contentValues.put(attendentColumn, Attendee);
      contentValues.put("SpotNo", spotNo);
      long update=db.update(tableName,contentValues,"Registration=?",new String[]{spotNo});
        if(update==-1) return false;
        else  return true;
  }

    public Cursor lookup(String Registration){
        SQLiteDatabase db=this.getReadableDatabase();
        String where="Registration =?";
        String[] whereArgs={Registration};

        return db.query(tableName2,null,where,whereArgs,null,null,null);

    }
    public boolean UpdatePass(String name, String id, String state, String registration,
                              String Attendee, String PkgType)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(nameColumn, name);
        contentValues.put(idColumn, id);
        contentValues.put(stateColumn, state);
        contentValues.put(registrationColumn, registration);
        contentValues.put(attendentColumn, Attendee);
        contentValues.put("PackageNumber", PkgType);
        long update=db.update(tableName,contentValues,"Registration=?",new String[]{PkgType});
        if(update==-1) return false;
        else  return true;
    }
    public boolean insertMember(String name, String id, String state, String registration,
                          String date, String Attendee, String PkgType,String pkgEx)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(nameColumn, name);
        contentValues.put(idColumn, id);
        contentValues.put(stateColumn, state);
        contentValues.put(registrationColumn, registration);
        contentValues.put(dateColumn, date);
        contentValues.put(attendentColumn, Attendee);
        contentValues.put("PackageType", PkgType);
        contentValues.put("PackageExpire", pkgEx);
        long ins=db.insert(tableName,null,contentValues);
        if(ins==-1) return false;
        else return true;

    }
}