package net.androidbootcamp.parkassist;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Calendar calender;
    SimpleDateFormat simpleDateFormat;
    String date;
    String time;
    TextView DateView, TimeView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FloatingActionButton fabHome = (FloatingActionButton) findViewById(R.id.float_home);
        fabHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchLayoutInfo();


            }
        });


    }

    public void switchLayout(View view) {
        //getTime();
        Intent searchIntent = new Intent(MainActivity.this, driverInformation.class);
        startActivity(searchIntent);
    }

    public void switchLayout2(View view) {
        Intent searchIntent = new Intent(MainActivity.this, unPark.class);
        startActivity(searchIntent);
    }

    public void switchLayoutInfo() {
        Intent searchIntent = new Intent(MainActivity.this, information.class);
        startActivity(searchIntent);
    }
    public void switchLayoutParkM(View view) {
        //getTime();
        Intent searchIntent = new Intent(MainActivity.this, parkMember.class);
        startActivity(searchIntent);
    }
    public void switchLayoutUnparkM(View view) {
        //getTime();
        Intent searchIntent = new Intent(MainActivity.this, unparkMember.class);
        startActivity(searchIntent);
    }
    public void switchLayoutAddM(View view) {
        //getTime();
        Intent searchIntent = new Intent(MainActivity.this, addMember.class);
        startActivity(searchIntent);
    }
    public void switchLayoutRenew(View view) {
        //getTime();
        Intent searchIntent = new Intent(MainActivity.this, renewMember.class);
        startActivity(searchIntent);
    }
}

