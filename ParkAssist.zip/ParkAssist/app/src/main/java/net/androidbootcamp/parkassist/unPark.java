package net.androidbootcamp.parkassist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class unPark extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_un_park);
        String time="15:56";
        String date="12/13/18";





    }
}
