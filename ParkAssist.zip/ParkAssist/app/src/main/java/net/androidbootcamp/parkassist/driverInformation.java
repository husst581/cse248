package net.androidbootcamp.parkassist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class driverInformation extends AppCompatActivity {
 databaseClass db;
    EditText driverID;
    EditText stateOfId;
    EditText Drivername;
    EditText RegistrationNo;
    EditText timeArrival;
    EditText dateOfArrival;
    EditText attandee;
    String idDriver;
    String idState;
    String DriverName;
    String registration;
    String timeArrive;
    String dateArrive;
    String Attendee;
    String SpotNo="1";
    public Boolean[] spotArray;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_information);
//getting values from editText and storing those into array classes
        db= new databaseClass(this);
        // sending edit text fields to another activity
        driverID = (EditText) (findViewById(R.id.driverId));
        stateOfId = (EditText) (findViewById(R.id.state));
        Drivername = (EditText) (findViewById(R.id.fullName));
        RegistrationNo = (EditText) (findViewById(R.id.registration));
        timeArrival = (EditText) (findViewById(R.id.ArrivalTime));
        dateOfArrival = (EditText) (findViewById(R.id.date));
        attandee = (EditText) (findViewById(R.id.attendee));



            }
    public void generateReceipt(View view){
        //assinging values to strings
        idDriver= driverID.getText().toString();
        idState= stateOfId.getText().toString();
        DriverName= Drivername.getText().toString();
        registration= RegistrationNo.getText().toString();
        timeArrive= timeArrival.getText().toString();
        dateArrive= dateOfArrival.getText().toString();
        Attendee= attandee.getText().toString();

        storeData(DriverName,idDriver,idState,registration,dateArrive,timeArrive,Attendee,SpotNo);

        Intent intent = new Intent(driverInformation.this, parkingTicket.class);
        //intent.putExtra( "driverId", idDriver);
        intent.putExtra( "driverName", DriverName);
        //intent.putExtra( "stateOfId", idState);
        intent.putExtra( "registration", registration);
        intent.putExtra( "time", timeArrive);
        intent.putExtra( "date", dateArrive);
        intent.putExtra( "attendee", Attendee);
        intent.putExtra( "spotNo", SpotNo);
        startActivity(intent);

        }
    public void storeData(String driver, String id, String state, String registration, String date, String time, String Attendee ,String spot) {
        if(driver.equals("")|| id.equals("")||
                state.equals("")|| registration.equals("")||
        time.equals("")||Attendee.equals("")){
            Toast.makeText(getApplicationContext(),"fields are empty",Toast.LENGTH_SHORT).show();
        }
        else {
            Boolean ins= db.insert(driver,id,state,registration,date,time,Attendee,spot);
            if(ins==true){
                Toast.makeText(getApplicationContext(),"data inserted",Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(getApplicationContext(),"no data stored",Toast.LENGTH_SHORT).show();
            }

        }
    }
}

