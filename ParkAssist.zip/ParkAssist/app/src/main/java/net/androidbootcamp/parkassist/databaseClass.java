package net.androidbootcamp.parkassist;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class databaseClass  extends SQLiteOpenHelper {
   public static final String tableName="DriverInformation";
    public static final  String nameColumn="Name";
    public static final  String idColumn="DriversID";
    public static final  String registrationColumn="Registration";
    public static final  String stateColumn="StateofID";
    public static final  String dateColumn="Date";
    public static final  String timeColumn="Time";
    public static final  String attendentColumn="Attendee";
    public databaseClass(Context context) {
        super(context, "driverData.db" , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + tableName +
                  "(ID integer primary key autoincrement,"
                + nameColumn +" text,"
                + idColumn + " text,"
                + stateColumn+" text,"
                + registrationColumn+ " text,"
                +dateColumn+" text,"
                +timeColumn+" text,"
                +attendentColumn+ " text, SpotNo text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + tableName );
    }
    public boolean insert(String name, String id, String state, String registration,
    String date, String time, String Attendee, String spotNo)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(nameColumn, name);
        contentValues.put(idColumn, id);
        contentValues.put(stateColumn, state);
        contentValues.put(registrationColumn, registration);
        contentValues.put(dateColumn, date);
        contentValues.put(timeColumn, time);
        contentValues.put(attendentColumn, Attendee);
        contentValues.put("SpotNo", spotNo);
        long ins=db.insert(tableName,null,contentValues);
        if(ins==-1) return false;
        else return true;

    }

}
