package net.androidbootcamp.parkassist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.support.design.widget.FloatingActionButton;

public class parkingTicket extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking_ticket);
        //floating point
        FloatingActionButton fabHome = (FloatingActionButton) findViewById(R.id.float_home);
        fabHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchLayout();


            }
        });
        //textview initialzed
        TextView driverName = (TextView) findViewById(R.id.NameTicket);
        TextView registrationNo = (TextView) findViewById(R.id.registrationTicket);
        TextView attendee = (TextView) findViewById(R.id.attendeeTicket);
        TextView arrival = (TextView) findViewById(R.id.timeArrivalTicket);
        TextView datearrive = (TextView) findViewById(R.id.dateTicket);
        TextView spotno=(TextView)findViewById(R.id.spotNoTicket);
        //assinging values  to strings which are coming from driverInformation to textboxes in ticket print layout
        Intent intent = getIntent();
        String drivername = intent.getStringExtra("driverName");
        String registration = intent.getStringExtra("registration");
        String timearrive = intent.getStringExtra("time");
        String dateArrive = intent.getStringExtra("date");
        String attende = intent.getStringExtra("attendee");
        String spotNo = intent.getStringExtra("spotNo");
        // textviews are equal to string
        driverName.setText(drivername);
        registrationNo.setText(registration);
        attendee.setText(attende);
        arrival.setText(timearrive);
        datearrive.setText(dateArrive);
        spotno.setText(spotNo);
    }

    public void switchLayout() {
        Intent searchIntent = new Intent(parkingTicket.this, MainActivity.class);
        startActivity(searchIntent);
    }
}