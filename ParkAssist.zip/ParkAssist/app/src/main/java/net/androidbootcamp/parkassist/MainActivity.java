package net.androidbootcamp.parkassist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Calendar calender;
    SimpleDateFormat simpleDateFormat;
    String date;
    String time;
    TextView DateView, TimeView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //DateView = findViewById(R.id.ArrivalTime);
        //TimeView = findViewById(R.id.date);


    }

    public void switchLayout(View view) {
        //getTime();
        Intent searchIntent = new Intent(MainActivity.this, driverInformation.class);
        startActivity(searchIntent);
    }

    public void switchLayout2(View view) {
        Intent searchIntent = new Intent(MainActivity.this, parkingTicket.class);
        startActivity(searchIntent);
    }

    //public void getTime() {
       // calender = Calendar.getInstance();
       // simpleDateFormat = new SimpleDateFormat("dd/MM/yyHH:mm:ss");
       // String timeDate = simpleDateFormat.format(calender.getTime());
       // date = timeDate.substring(0,7);
       // time = timeDate.substring(8);
        //DateView.setText(date.toString());
        //TimeView.setText(time.toString());

    }
